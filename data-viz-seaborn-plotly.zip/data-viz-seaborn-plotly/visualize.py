# -*- coding: utf-8 -*-
"""
Визуализация данных с использованием Seaborn и Plotly.

Датасет: Titanic (891 строка) — числовые (age, fare, sibsp, parch) и
категориальные (sex, class, embarked, survived) признаки.

Скрипт выполняет предобработку (очистка, обработка пропусков, приведение типов)
и строит визуализации:
  Seaborn: распределение (hist+kde), scatterplot, boxplot, heatmap корреляций.
  Plotly:  scatterplot, line plot, bar chart, heatmap, интерактивный dropdown.

Все графики содержат подписи осей и заголовки. Seaborn-графики сохраняются в
images/*.png, Plotly-графики — в plots/*.html (интерактивные) и images/*.png.
"""

import os
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go

warnings.filterwarnings("ignore")
plt.rcParams["font.family"] = "DejaVu Sans"
sns.set_theme(style="whitegrid")

HERE = os.path.dirname(os.path.abspath(__file__))
IMG = os.path.join(HERE, "images")
PLOTS = os.path.join(HERE, "plots")
os.makedirs(IMG, exist_ok=True)
os.makedirs(PLOTS, exist_ok=True)


# --------------------------------------------------------------------------- #
#  1. Загрузка и предобработка
# --------------------------------------------------------------------------- #
def load_and_preprocess():
    df = pd.read_csv(os.path.join(HERE, "data", "titanic_raw.csv"))
    print(f"Исходный датасет: {df.shape[0]} строк, {df.shape[1]} столбцов")
    print("Пропуски до обработки:")
    print(df[["age", "embarked", "deck"]].isna().sum().to_string())

    # --- Очистка: удаляем дубликаты и малоинформативные/дублирующие столбцы
    df = df.drop_duplicates()
    # deck: 688 из 891 пропусков — столбец удаляем
    df = df.drop(columns=["deck", "alive", "embark_town", "who",
                          "adult_male", "alone"], errors="ignore")

    # --- Обработка пропусков
    # age: заполняем медианой по группе (пол, класс) — точнее общей медианы
    df["age"] = df.groupby(["sex", "pclass"])["age"].transform(
        lambda s: s.fillna(s.median()))
    # embarked: заполняем самым частым значением (модой)
    df["embarked"] = df["embarked"].fillna(df["embarked"].mode()[0])

    # --- Приведение типов
    df["survived"] = df["survived"].astype(int)
    df["pclass"] = df["pclass"].astype(int)
    for col in ["sex", "embarked", "class"]:
        df[col] = df[col].astype("category")
    # производный числовой признак
    df["family_size"] = df["sibsp"] + df["parch"] + 1

    print(f"\nПосле обработки: {df.shape[0]} строк, {df.shape[1]} столбцов, "
          f"пропусков осталось: {int(df.isna().sum().sum())}")
    print("Типы признаков:")
    print(df.dtypes.to_string())
    return df


# --------------------------------------------------------------------------- #
#  2. Графики Seaborn
# --------------------------------------------------------------------------- #
def seaborn_plots(df):
    num_cols = ["survived", "pclass", "age", "sibsp", "parch", "fare", "family_size"]

    # 2.1 Распределение (гистограмма + KDE)
    plt.figure(figsize=(8, 5))
    sns.histplot(data=df, x="age", hue="sex", kde=True, bins=30)
    plt.title("Распределение возраста пассажиров (hist + KDE)")
    plt.xlabel("Возраст, лет")
    plt.ylabel("Количество пассажиров")
    plt.tight_layout()
    plt.savefig(os.path.join(IMG, "sns_1_distribution.png"), dpi=140)
    plt.close()

    # 2.2 Scatterplot
    plt.figure(figsize=(8, 5))
    sns.scatterplot(data=df, x="age", y="fare", hue="class", style="sex", alpha=0.7)
    plt.title("Зависимость стоимости билета от возраста")
    plt.xlabel("Возраст, лет")
    plt.ylabel("Стоимость билета, $")
    plt.tight_layout()
    plt.savefig(os.path.join(IMG, "sns_2_scatter.png"), dpi=140)
    plt.close()

    # 2.3 Boxplot
    plt.figure(figsize=(8, 5))
    sns.boxplot(data=df, x="class", y="age", hue="sex")
    plt.title("Распределение возраста по классам и полу (boxplot)")
    plt.xlabel("Класс каюты")
    plt.ylabel("Возраст, лет")
    plt.tight_layout()
    plt.savefig(os.path.join(IMG, "sns_3_boxplot.png"), dpi=140)
    plt.close()

    # 2.4 Heatmap корреляций
    plt.figure(figsize=(8, 6))
    corr = df[num_cols].corr()
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0,
                square=True, linewidths=0.5)
    plt.title("Матрица корреляций числовых признаков")
    plt.tight_layout()
    plt.savefig(os.path.join(IMG, "sns_4_heatmap.png"), dpi=140)
    plt.close()
    print("Seaborn: 4 графика сохранены в images/")


# --------------------------------------------------------------------------- #
#  3. Графики Plotly
# --------------------------------------------------------------------------- #
def plotly_plots(df):
    def save(fig, name):
        fig.write_html(os.path.join(PLOTS, name + ".html"),
                       include_plotlyjs="cdn", full_html=True)
        try:
            fig.write_image(os.path.join(IMG, name + ".png"), width=900, height=520, scale=2)
        except Exception as e:
            print(f"  (PNG-превью для {name} не создано: {e})")

    # 3.1 Scatterplot
    fig = px.scatter(df, x="age", y="fare", color="class", symbol="sex",
                     title="Plotly: стоимость билета и возраст пассажиров",
                     labels={"age": "Возраст, лет", "fare": "Стоимость билета, $",
                             "class": "Класс", "sex": "Пол"},
                     hover_data=["survived", "family_size"])
    save(fig, "plotly_1_scatter")

    # 3.2 Line plot — доля выживших по возрастным группам
    df_line = df.copy()
    df_line["age_bin"] = pd.cut(df_line["age"], bins=range(0, 90, 10), right=False)
    rate = df_line.groupby("age_bin", observed=True)["survived"].mean().reset_index()
    rate["age_label"] = rate["age_bin"].apply(lambda b: f"{int(b.left)}–{int(b.right)}")
    fig = px.line(rate, x="age_label", y="survived", markers=True,
                  title="Plotly: доля выживших по возрастным группам",
                  labels={"age_label": "Возрастная группа, лет", "survived": "Доля выживших"})
    fig.update_yaxes(tickformat=".0%")
    save(fig, "plotly_2_line")

    # 3.3 Bar chart — доля выживших по классу и полу
    bar = df.groupby(["class", "sex"], observed=True)["survived"].mean().reset_index()
    fig = px.bar(bar, x="class", y="survived", color="sex", barmode="group",
                 title="Plotly: доля выживших по классу и полу",
                 labels={"class": "Класс каюты", "survived": "Доля выживших", "sex": "Пол"})
    fig.update_yaxes(tickformat=".0%")
    save(fig, "plotly_3_bar")

    # 3.4 Heatmap корреляций
    num_cols = ["survived", "pclass", "age", "sibsp", "parch", "fare", "family_size"]
    corr = df[num_cols].corr().round(2)
    fig = px.imshow(corr, text_auto=True, color_continuous_scale="RdBu_r",
                    zmin=-1, zmax=1, aspect="auto",
                    title="Plotly: матрица корреляций числовых признаков")
    fig.update_xaxes(title="Признак")
    fig.update_yaxes(title="Признак")
    save(fig, "plotly_4_heatmap")

    # 3.5 Интерактивный элемент — dropdown для выбора числовой оси Y
    y_options = ["fare", "age", "sibsp", "parch", "family_size"]
    y_titles = {"fare": "Стоимость билета, $", "age": "Возраст, лет",
                "sibsp": "Супруги/братья на борту", "parch": "Родители/дети на борту",
                "family_size": "Размер семьи"}
    fig = go.Figure()
    colors = {"First": "#2C6FBB", "Second": "#1F9D55", "Third": "#B8001F"}
    for cls in df["class"].cat.categories:
        sub = df[df["class"] == cls]
        fig.add_trace(go.Scatter(x=sub["age"], y=sub["fare"], mode="markers",
                                 name=str(cls), marker=dict(color=colors.get(cls)),
                                 hovertemplate="Возраст: %{x}<br>%{y}<extra></extra>"))
    buttons = []
    for y in y_options:
        buttons.append(dict(
            label=y_titles[y], method="update",
            args=[{"y": [df[df["class"] == cls][y] for cls in df["class"].cat.categories]},
                  {"yaxis": {"title": y_titles[y]}}]))
    fig.update_layout(
        title="Plotly (интерактивно): выберите числовой признак по оси Y (dropdown)",
        xaxis_title="Возраст, лет", yaxis_title=y_titles["fare"],
        updatemenus=[dict(buttons=buttons, direction="down", showactive=True,
                          x=1.0, xanchor="right", y=1.15, yanchor="top")])
    save(fig, "plotly_5_interactive_dropdown")
    print("Plotly: 5 графиков сохранены в plots/ (HTML) и images/ (PNG-превью)")


def main():
    print("=" * 60)
    df = load_and_preprocess()
    print("=" * 60)
    seaborn_plots(df)
    plotly_plots(df)
    print("=" * 60)
    print("Готово.")


if __name__ == "__main__":
    main()
